import { Post, PostMetadata } from './Entity'
import { DataMapper, DataMapperConfiguration } from '@aws/dynamodb-data-mapper'
import { between } from '@aws/dynamodb-expressions'
import DynamoDB = require('aws-sdk/clients/dynamodb')

// const client = new DynamoDB({ region: 'us-west-2' })
// const mapper = new DataMapper({ client })

// const post = new Post()
// post.createdAt = new Date()
// post.authorUsername = 'User1'
// post.title = 'Hello, DataMapper'
// post.metadata = Object.assign(new PostMetadata(), {
//   draft: true,
//   tags: new Set(['greeting', 'introduction', 'en-US']),
// })

// mapper.put({ item: post }).then(() => {
//   // The post has been created!
//   console.log(post.id)
// })

// for await (const post of mapper.scan({valueConstructor: Post})) {
//   // Each post is an instance of the Post class
// }

export class Service {
  private readonly model: DataMapper

  constructor() {
    const client = new DynamoDB({ region: 'ap-southeast-2' })
    // const mapper = new DataMapper({ client })
    this.model = new DataMapper({ client })
  }

  // async find(selector?: Partial<Post>) {
  //   const iterator = this.model.query({
  //     valueConstructor: Post,
  //     keyCondition: {
  //         hashKey: selector.,
  //         rangeKey: between(10, 99)
  //     }
  // });

  // for await (const item of iterator) {
  //     // Each post is an instance of MyDomainClass
  // }
  //   return this.model.find(selector)
  // }

  async create(post: Post) {
    await this.model.put({ item: post })
    console.log('Saved post id: ', post.id)
  }
  async get(_id: string) {
    const toFetch = new Post()
    toFetch.id = _id
    return await this.model.get({ item: toFetch })
  }

  async delete(_id: string) {
    const post = await this.get(_id)
    return await this.model.delete({ item: post })
  }
}

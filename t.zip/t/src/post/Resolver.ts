import { Arg, Resolver, Query, Authorized, Mutation, Ctx, ID, InputType, Field } from 'type-graphql'
import { Service } from './Service'
import { Post, PostMetadata } from './Entity'

post interface Context {
  post?: Post;
  postId: string;
}

@InputType()
class PostInput implements Partial<Post> {
  @Field(type => String)
  authorName: string

  @Field(type => String)
  title: string

  @Field(type => PostMetadataInput)
  metadata: PostMetadataInput
}

@InputType()
class PostMetadataInput implements Partial<PostMetadata> {
  @Field(type => Boolean)
  draft: boolean

  @Field(type => Set)
  tags: Set<string>
}

@Resolver(Post)
export default class PostResolver {
  private readonly service: Service

  constructor() {
    this.service = new Service()
  }

  // @Query(returns => User)
  // @Authorized()
  // async me(@Ctx() ctx: Context) {
  //   if (ctx.userId) {
  //     return await this.service.findOneById(ctx.userId)
  //   }
  // }

  @Query(returns => Post)
  async get(@Ctx() ctx: Context) {
    if (ctx.postId) {
      return await this.service.get(ctx.postId)
    }
  }

  // this overrides accounts js `createUser` function
  // @Mutation(returns => ID)
  // async createUser(@Arg('user', returns => CreateUserInput) user: CreateUserInput) {
  //   const createdUserId = await accountsPassword.createUser({
  //     ...user,
  //     roles: [Role.User],
  //   })

  //   return createdUserId
  // }

  // @Mutation(returns => Boolean)
  // @Authorized()
  // async onboardUser(
  //   @Arg('publicToken') publicToken: string,
  //   @Arg('property') property: PropertyInput,
  //   @Ctx() ctx: Context
  // ) {
  //   return new Promise((resolve, reject) => {
  //     plaid.exchangePublicToken(publicToken, async (err, response) => {
  //       if (err != null) reject(err)

  //       const user = await this.service.findOneById(ctx.userId)
  //       user.plaid = {
  //         accessToken: response.access_token,
  //         itemId: response.item_id,
  //       }
  //       user.properties = [property]
  //       user.isOnboarded = true
  //       await user.save()

  //       resolve(true)
  //     })
  //   })
  // }

  // @Mutation(returns => Boolean)
  // @Authorized()
  // async setPlaidToken(@Arg('publicToken') publicToken: string, @Ctx() ctx: Context) {
  //   return new Promise((resolve, reject) => {
  //     plaid.exchangePublicToken(publicToken, async (err, response) => {
  //       if (err != null) reject(err)

  //       const user = await this.service.findOneById(ctx.userId)
  //       user.plaid = {
  //         accessToken: response.access_token,
  //         itemId: response.item_id,
  //       }
  //       await user.save()

  //       resolve(true)
  //     })
  //   })
  // }

  // @FieldResolver(returns => String)
  // async firstName(@Root() user: User) {
  //   return user.profile.firstName
  // }

  // @FieldResolver(returns => String)
  // async lastName(@Root() user: User) {
  //   return user.profile.lastName
  // }
}

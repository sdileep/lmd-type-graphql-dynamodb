import { ApolloServer, gql } from "apollo-server-lambda";
import { CommentService } from "./comment.service";

const typeDefs = gql`
  type Comment {
    msgId: Int
    userId: String
    content: String
    createdAt: String
    deleted: Boolean
  }
  type Query {
    get(itemId: String): [Comment]
  }
  type Mutation {
    add(itemId: String, userId: String, content: String): [Comment]
    edit(itemId: String, msgId: Int, userId: String, content: String): [Comment]
    delete(itemId: String, msgId: Int, userId: String): [Comment]
  }
`;

const resolvers = {
  Query: {
    // Get Comments
    get: (root, args) => {
      try {
        console.log(root);
        const service = new CommentService();
        return service.getComments(args.itemId);
      } catch (error) {
        console.log("Error: ", error);
      }
    }
  },
  Mutation: {
    // Add Comments
    add: (roots, args) => {
      try {
        console.log(roots);
        const service = new CommentService();
        return service.addComments(args.itemId, args.userId, args.content);
      } catch (error) {
        console.log("Error: ", error);
      }
    },
    //Edit Comment
    edit: (roots, args) => {
      console.log(roots);
      const service = new CommentService();
      return service.editComments(
        args.itemId,
        args.msgId,
        args.userId,
        args.content
      );
    },
    // Delete Comment
    delete: (roots, args) => {
      console.log(roots);
      const service = new CommentService();
      return service.deleteComments(args.itemId, args.msgId, args.userId);
    }
  }
};

const server = new ApolloServer({
  typeDefs,
  resolvers
});

export const graphqlHandler = server.createHandler({
  cors: {
    origin: true,
    credentials: true
  }
});

// const aws = require('aws-sdk');
// const codedeploy = new aws.CodeDeploy({apiVersion: '2014-10-06'});

// module.exports.pre = (event, context, callback) => {
//   var deploymentId = event.DeploymentId;
//   var lifecycleEventHookExecutionId = event.LifecycleEventHookExecutionId;

//   console.log('We are running some integration tests before we start shifting traffic...');

//   var params = {
//       deploymentId: deploymentId,
//       lifecycleEventHookExecutionId: lifecycleEventHookExecutionId,
//       status: 'Succeeded' // status can be 'Succeeded' or 'Failed'
//   };

//   return codedeploy.putLifecycleEventHookExecutionStatus(params).promise()
//     .then(data => callback(null, 'Validation test succeeded'))
//     .catch(err => callback('Validation test failed'));
// };

// module.exports.post = (event, context, callback) => {
//   var deploymentId = event.DeploymentId;
//   var lifecycleEventHookExecutionId = event.LifecycleEventHookExecutionId;

//   console.log('Check some stuff after traffic has been shifted...');

//   var params = {
//       deploymentId: deploymentId,
//       lifecycleEventHookExecutionId: lifecycleEventHookExecutionId,
//       status: 'Succeeded' // status can be 'Succeeded' or 'Failed'
//   };

//   return codedeploy.putLifecycleEventHookExecutionStatus(params).promise()
//     .then(data => callback(null, 'Validation test succeeded'))
//     .catch(err => callback('Validation test failed'));
// };
